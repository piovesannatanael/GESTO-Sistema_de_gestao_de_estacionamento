# pagamentos_modal/models.py

from django.db import models
from django.utils import timezone
from estadias.models import Estadia
from funcionarios.models import Funcionario
from decimal import Decimal

# --- PREÇOS BASE PARA CADA MODALIDADE ---
PRECOS_PLANOS = {
    'diaria': Decimal('15.00'),
    'semanal': Decimal('50.00'),
    'mensal': Decimal('200.00'),
}


class PagamentoModal(models.Model):
    """
    Modelo para gerenciar pagamentos de estadias por planos
    (diária, semanal, mensal).
    """
    PLANO_CHOICES = (
        ('diaria', 'Diária'),
        ('semanal', 'Semanal'),
        ('mensal', 'Mensal'),
    )
    METODO_CHOICES = (
        ('PIX', 'PIX'),
        ('DINHEIRO', 'Dinheiro'),
        ('CARTAO', 'Cartão'),
    )

    estadia = models.OneToOneField(
        Estadia,
        on_delete=models.CASCADE,
        related_name='pagamento_modal'
    )
    plano_contratado = models.CharField(
        'Plano Contratado',
        max_length=10,
        choices=PLANO_CHOICES
    )
    metodo = models.CharField('Método de Pagamento', max_length=20, choices=METODO_CHOICES)

    valor_bruto = models.DecimalField(
        'Valor Bruto (sem descontos)',
        max_digits=8,
        decimal_places=2,
        null=True, blank=True
    )
    desconto_aplicado = models.DecimalField(
        'Desconto Aplicado',
        max_digits=8,
        decimal_places=2,
        default=Decimal('0.00')
    )
    valor_final = models.DecimalField(
        'Valor Final (a pagar)',
        max_digits=8,
        decimal_places=2,
        null=True, blank=True
    )
    data_pagamento = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = 'Pagamento por Modalidade'
        verbose_name_plural = 'Pagamentos por Modalidade'

    def __str__(self):
        return f'Pagamento ({self.get_plano_contratado_display()}) para {self.estadia.veiculo.placa}'

    def calcular_valores(self):
        """
        Calcula o valor final do pagamento com base no plano contratado,
        aplicando acréscimos e descontos.
        """
        # --- 1. Obter Preço Base do Plano ---
        preco_base = PRECOS_PLANOS.get(self.plano_contratado, Decimal('0.00'))

        # --- 2. Aplicar Acréscimo com base na Categoria do Veículo ---
        veiculo = self.estadia.veiculo
        acrescimo = Decimal('0.00')

        qtd_rodas_str = str(getattr(veiculo, 'qtd_rodas', '0'))

        if qtd_rodas_str == '2':
            acrescimo = preco_base * Decimal('0.02')  # Acréscimo de 2%
        elif qtd_rodas_str in ['3', '4 ou mais']:
            acrescimo = preco_base * Decimal('0.03')  # Acréscimo de 3%

        valor_bruto = preco_base + acrescimo

        # NOTA: A regra de multa por +12h não se aplica a planos de preço fixo.

        # --- 3. Calcular e Aplicar o Maior Desconto Disponível ---
        desconto_funcionario = Decimal('0.00')
        desconto_pagamento = Decimal('0.00')

        if self.estadia.cliente and hasattr(self.estadia.cliente, 'cpf'):
            is_funcionario = Funcionario.objects.filter(cpf=self.estadia.cliente.cpf).exists()
            if is_funcionario:
                desconto_funcionario = valor_bruto * Decimal('0.20')

        if self.metodo in ['PIX', 'DINHEIRO']:
            desconto_pagamento = valor_bruto * Decimal('0.15')

        maior_desconto = max(desconto_funcionario, desconto_pagamento)
        valor_final = valor_bruto - maior_desconto

        return {
            'valor_bruto': round(valor_bruto, 2),
            'desconto': round(maior_desconto, 2),
            'valor_final': round(valor_final, 2),
        }

    def save(self, *args, **kwargs):
        # Calcula os valores automaticamente na criação do pagamento
        if not self.pk:
            valores = self.calcular_valores()
            self.valor_bruto = valores['valor_bruto']
            self.desconto_aplicado = valores['desconto']
            self.valor_final = valores['valor_final']

        # Atualiza a estadia relacionada
        if self.valor_final is not None:
            self.estadia.valor_total = self.valor_final
            self.estadia.finalizada = True
            self.estadia.save()

        super().save(*args, **kwargs)
