from django import forms
from .models import PagamentoModal

class PagamentoModalidadeForm(forms.ModelForm):
    class Meta:
        model = PagamentoModal
        fields = ['valor_pago', 'metodo']
        widgets = {
            'valor_pago': forms.NumberInput(attrs={'readonly': True}),
        }
