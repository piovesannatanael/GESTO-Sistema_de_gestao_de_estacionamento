from django.apps import AppConfig


class PagamentoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pagamentos_avulso'
    verbose_name = 'Controle de Pagamentos'
