# pagamentos_avulsos/models.py

from django.db import models
from django.utils import timezone
from estadias.models import Estadia  # Você precisa importar o modelo Estadia
from funcionarios.models import Funcionario  # Importe o modelo de Funcionário para o desconto
from decimal import Decimal
from datetime import timedelta

# Defina o preço base aqui para fácil manutenção
PRECO_HORA_BASE = Decimal('10.00')  # Defina o valor base da hora


class PagamentoAvulso(models.Model):
    METODO_CHOICES = (
        ('PIX', 'PIX'),
        ('DINHEIRO', 'Dinheiro'),
        ('CARTAO', 'Cartão'),
    )

    estadia = models.OneToOneField(
        Estadia,
        on_delete=models.CASCADE,
        related_name='pagamento_avulso'  # Boa prática renomear o related_name
    )
    metodo = models.CharField('Método', max_length=20, choices=METODO_CHOICES)

    # Campos adicionados para maior clareza no cálculo
    valor_bruto = models.DecimalField(
        'Valor Bruto (sem descontos)',
        max_digits=8,
        decimal_places=2,
        null=True, blank=True
    )
    desconto_aplicado = models.DecimalField(
        'Desconto Aplicado',
        max_digits=8,
        decimal_places=2,
        default=Decimal('0.00')
    )
    valor_final = models.DecimalField(
        'Valor Final (a pagar)',
        max_digits=8,
        decimal_places=2,
        null=True, blank=True
    )

    data_pagamento = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = 'Pagamento Avulso'
        verbose_name_plural = 'Pagamentos Avulsos'

    def __str__(self):
        return f'Pagamento para a estada do veículo {self.estadia.veiculo.placa}'

    def calcular_valores(self):
        """
        Executa todas as regras de negócio para calcular o valor final do pagamento avulso.
        """
        if not self.estadia.data_saida:
            return {'valor_bruto': Decimal('0.00'), 'desconto': Decimal('0.00'), 'valor_final': Decimal('0.00')}

        # --- 1. Calcular Preço Base pela Duração ---
        duracao = self.estadia.data_saida - self.estadia.data_chegada
        # Arredonda as horas para cima (qualquer fração de hora conta como uma hora inteira)
        horas_arredondadas = int((duracao.total_seconds() + 3599) // 3600)
        preco_base = PRECO_HORA_BASE * max(1, horas_arredondadas)

        # --- 2. Aplicar Acréscimo com base na Categoria do Veículo ---
        # SUPOSIÇÃO: O modelo Veiculo tem um campo `qtd_rodas` (ex: IntegerField ou CharField).
        veiculo = self.estadia.veiculo
        acrescimo = Decimal('0.00')

        # Usamos `str()` para garantir a comparação
        qtd_rodas_str = str(getattr(veiculo, 'qtd_rodas', '0'))

        if qtd_rodas_str == '2':
            acrescimo = preco_base * Decimal('0.02')  # Acréscimo de 2%
        elif qtd_rodas_str in ['3', '4 ou mais']:
            acrescimo = preco_base * Decimal('0.03')  # Acréscimo de 3%

        valor_com_acrescimo = preco_base + acrescimo

        # --- 3. Aplicar Multa por Longa Permanência (> 12h) ---
        valor_bruto = valor_com_acrescimo
        if duracao > timedelta(hours=12):
            multa = valor_bruto * Decimal('0.50')  # Multa de 50%
            valor_bruto += multa

        # --- 4. Calcular e Aplicar o Maior Desconto Disponível ---
        desconto_funcionario = Decimal('0.00')
        desconto_pagamento = Decimal('0.00')

        # Desconto para funcionários (20%)
        # SUPOSIÇÃO: A Estadia tem um campo 'cliente' e o Cliente tem um campo 'cpf'.
        if self.estadia.cliente and hasattr(self.estadia.cliente, 'cpf'):
            is_funcionario = Funcionario.objects.filter(cpf=self.estadia.cliente.cpf).exists()
            if is_funcionario:
                desconto_funcionario = valor_bruto * Decimal('0.20')

        # Desconto por método de pagamento (15%)
        if self.metodo in ['PIX', 'DINHEIRO']:
            desconto_pagamento = valor_bruto * Decimal('0.15')

        # A regra é aplicar o maior desconto, não acumular
        maior_desconto = max(desconto_funcionario, desconto_pagamento)
        valor_final = valor_bruto - maior_desconto

        return {
            'valor_bruto': round(valor_bruto, 2),
            'desconto': round(maior_desconto, 2),
            'valor_final': round(valor_final, 2),
        }

    def save(self, *args, **kwargs):
        # Calcula os valores automaticamente ao criar um novo registro de pagamento
        if not self.pk:
            valores = self.calcular_valores()
            self.valor_bruto = valores['valor_bruto']
            self.desconto_aplicado = valores['desconto']
            self.valor_final = valores['valor_final']

        # Atualiza a estadia relacionada
        if self.valor_final is not None:
            self.estadia.valor_total = self.valor_final
            self.estadia.finalizada = True
            self.estadia.save()

        super().save(*args, **kwargs)