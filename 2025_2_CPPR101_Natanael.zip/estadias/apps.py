from django.apps import AppConfig


class EstadaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'estadias'
    verbose_name = 'Controle de Estadias'
